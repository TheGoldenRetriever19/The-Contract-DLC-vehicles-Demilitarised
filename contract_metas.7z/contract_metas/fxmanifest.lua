fx_version "bodacious"
game "gta5"
author "Rio"


files {
    'data/*.meta'
}

data_file 'HANDLING_FILE' 'data/handling.meta'
data_file 'CARCOLS_FILE' 'data/carcols.meta'
data_file 'VEHICLE_VARIATION_FILE' 'data/carvariations.meta'